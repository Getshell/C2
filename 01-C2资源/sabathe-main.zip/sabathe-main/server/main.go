package main

import (
	"sabathe/server/cmd"
)

func main() {
	cmd.Execute()
}
