package main

import "sabathe/client/console"

func main() {
	console.ServiceConsole("127.0.0.1:8443")
}
