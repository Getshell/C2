package tansport

// request for implants
// select QUIC as the data return protocol
// select KCP as the command get protocol
