---
name: Feature request
about: Suggest an addition or cool new feature for NimPlant
title: ''
labels: ''
assignees: ''

---

- [ ] This issue is not about OPSEC or bypassing defensive products

---

**Feature Description**
