package config

var (
	AesKey = "Adba723b4fe06819"
)

const (
	Version  = "0.10.5"
	SystemId = "OrcaC2_" + Version
)
