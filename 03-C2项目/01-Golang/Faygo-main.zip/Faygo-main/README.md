# Faygo

* A RAT Tools on major platforms.
* The traffic data be encryped by aes.use aeskey and aesiv
* The net moudle now use http,it can be replace to other protocol.
## Now support
* Linux
* Drwin
* Windows

Now can run command and transfer files.

## Example
click the gif for full expample video
[![Watch the video](https://raw.githubusercontent.com/Maka8ka/Faygo/main/faygo.gif)](https://github.com/Maka8ka/Faygo/blob/main/faygo.m4v)
## Detection
![detection](https://raw.githubusercontent.com/Maka8ka/Faygo/main/detection.jpg)

## My Sapce
[Maka8ka's Garden](https://maka8ka.github.io)
