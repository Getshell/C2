#!/usr/bin/env python

import sys
import os

os.system("python -m pip list")

print("\n\nHello, if you see this line, emp3r0r's python is working")
print("Let's check some basic info\n")
print(f"sys.path = {sys.path}")
print(f"sys.argv = {sys.argv}")
print(f"sys.api_version = {sys.api_version}")
print(f"sys.platform= {sys.platform}")
print(f"ENV = {os.environ}\n\n")
