package cc

func Suicide() {
	SendCmdToCurrentTarget("suicide", "")
}
