package agent

func HasRoot() bool {
	return crossPlatformHasRoot()
}
