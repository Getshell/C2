package agent

func CheckContainer() string {
	return crossPlatformCheckContainer()
}
