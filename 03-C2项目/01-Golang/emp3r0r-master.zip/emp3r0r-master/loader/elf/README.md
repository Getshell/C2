See https://github.com/malisal/loaders

```bash
# build
make

# run
./demo.exe

# usage
# try injecting `loader.so` somewhere you like, be sure to put `emp3r0r` binary in the same dir
```
