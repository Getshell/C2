git clone https://github.com/paij0se/pairat
cd pairat
go get .
go build -o pairat main.go
echo "Done :D, now run ./pairat"