package main

import server "github.com/ELPanaJose/pairat/src"

func main() {
	server.StartServer()
}
