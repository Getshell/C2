# Stagers

Using stagers should be OPTIONAL, the point of this framework is to isolate the agents from the C2 servers so that users can develop they're own agents based on an api. That way its easier to evade AV for each individual red team.
 - Each stager corresponds to each listener version
 - http, http, etc
