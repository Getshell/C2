TODO
====
These are ideas for the future.  Some may even be implemented.

- Client-side DNS compatible with
  [dnsproxycommand](https://github.com/magisterquis/dnsproxycommand)
- Implant buildable as shared object file
- Set environment variables
- Optional b64 in f >
- Change argv with memfd_create'd binaries

Done
====
- Per-session working directiories
