package defaultDns

type Config struct {
}
