package template

type Registration struct {
}

func (reg *Registration) SetDefaults() {

}
