package main

import (
	"bytes"
	"encoding/json"
	"net/http"
	"os"
)

var hbkey string
var tokens []string
var programdata = os.Getenv("PROGRAMDATA")

func ErrorMessage(ID string) {
	msg := APIMessage{
		Content: "Something went wrong",
	}
	d, _ := json.Marshal(msg)
	req, err := http.NewRequest("POST", "https://discord.com/api/channels/"+ID+"/messages", bytes.NewBuffer(d))
	if err != nil {
		return
	}
	req.Header.Add("Authorization", Token)
	req.Header.Add("content-type", "application/json")
	client := &http.Client{}
	client.Do(req)
}
func SendToChannel(ID string, what APIMessage) {
	d, _ := json.Marshal(what)
	req, err := http.NewRequest("POST", "https://discord.com/api/channels/"+ID+"/messages", bytes.NewBuffer(d))
	if err != nil {
		ErrorMessage(ID)
	}
	req.Header.Add("Authorization", Token)
	req.Header.Add("Content-Type", "application/json")
	client := &http.Client{}
	client.Do(req)
}
