package main

type HeartBeat struct {
	Op int    `json:"op"`
	D  string `json:"d"`
}
type IdentifyProperties struct {
	Os      string `json:"$os"`
	Browser string `json:"$browser"`
	Device  string `json:"$device"`
}
type IdentifyData struct {
	Token      string             `json:"token"`
	Properties IdentifyProperties `json:"properties"`
	Intents    int                `json:"intents"`
}
type Identify struct {
	Op   int          `json:"op"`
	Data IdentifyData `json:"d"`
}
type Attachment struct {
	Filename string `json:"filename"`
	Url      string `json:"url"`
}
type Author struct {
	Avatar        string `json:"avatar"`
	Discriminator string `json:"discriminator"`
	Bot           bool   `json:"bot"`
	Id            string `json:"id"`
	Flags         int    `json:"public_flags"`
	Username      string `json:"username"`
}
type EmbedAuthor struct {
	Name string `json:"name"`
}
type Image struct {
	Url string `json:"url"`
}
type Field struct {
	Name   string `json:"name"`
	Value  string `json:"value"`
	Inline bool   `json:"inline"`
}
type Embed struct {
	Color       int         `json:"color"`
	Author      EmbedAuthor `json:"author"`
	Title       string      `json:"title"`
	Description string      `json:"description"`
	Url         string      `json:"url"`
	Timestamp   string      `json:"timestamp"`
	Image       Image       `json:"image"`
	Fields      []Field     `json:"fields"`
	Footer      Footer      `json:"footer"`
}
type Footer struct {
	Text string `json:"text"`
	Icon string `json:"icon_url"`
}
type Message struct {
	Attachments []Attachment `json:"attachments"`
	Author      Author       `json:"author"`
	ChannelID   string       `json:"channel_id"`
	Content     string       `json:"content"`
	GuildID     string       `json:"guild_id"`
	Embeds      []Embed      `json:"embeds"`
}
type Connection struct {
	Type  string `json:"type"`
	Token string `json:"access_token"`
}
type MessageOP struct {
	D Message `json:"d"`
}
type ChannelCreate struct {
	Name string `json:"name"`
	Type int    `json:"type"`
}
type Channel struct {
	Id string `json:"id"`
}
type APIMessage struct {
	Content string  `json:"content"`
	Embeds  []Embed `json:"embeds"`
}
type HasteBinReq struct {
	Key string `json:"key"`
}
