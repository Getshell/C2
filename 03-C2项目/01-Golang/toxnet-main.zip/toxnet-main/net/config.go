package net

// Admin public keys
var Admins = []string{"PLACE_YOUR_TOX_ID_RIGHT_HERE"}

// C2 Private Key
var Tox_key = "./c2.data"
