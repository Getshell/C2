# watchface

Custom watch face for ~~Ticwatch C2+~~ any watch running Linux with RGBA /dev/fb0 and 360x360 resolution

**Warning: this code is ugly and might be unstable**
