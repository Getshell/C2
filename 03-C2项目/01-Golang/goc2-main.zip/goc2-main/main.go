package main

import "github.com/grines/goc2/cmd/goc2"

func main() {
	goc2.Start()
}
