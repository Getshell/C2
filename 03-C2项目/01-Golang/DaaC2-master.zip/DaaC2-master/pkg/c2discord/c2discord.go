package c2discord

// Globals used for actually communicating with discord. These will change across bots/servers/channels
var (
	Token     = ""
	ChannelID = ""
)
