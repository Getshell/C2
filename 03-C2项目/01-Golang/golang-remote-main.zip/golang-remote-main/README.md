## golang remote
![alt_text](https://media.discordapp.net/attachments/757215782772932679/775560937742663690/Captura_de_Pantalla_2020-11-09_a_las_4.01.51_a.m..png?width=1508&height=943)
Rysty help me in the develop of this project and here is his github [rustyBalboaDev](https://github.com/RustyBalboadev)
<h3>you need to open the por 8090 </h3>
<h3> maybe you can use ngrok but for the request is dont the best practice </h3>
<h3>if you find a form to optimize this i will be thankful</h3>
<h4>
In the future this project is gona work with sockets
</h4>

