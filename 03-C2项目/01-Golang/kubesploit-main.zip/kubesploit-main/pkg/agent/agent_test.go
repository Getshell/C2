// Kubesploit is a post-exploitation command and control framework built on top of Merlin by Russel Van Tuyl.
// This file is part of Kubesploit.
// Copyright (c) 2021 CyberArk Software Ltd. All rights reserved.

// Kubesploit is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// any later version.

// Kubesploit is distributed in the hope that it will be useful for enhancing organizations' security.
// Kubesploit shall not be used in any malicious manner.
// Kubesploit is distributed AS-IS, WITHOUT ANY WARRANTY; including the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with Kubesploit.  If not, see <http://www.gnu.org/licenses/>.

package agent

import (
	// Standard
	"bytes"
	"crypto/sha256"
	"encoding/gob"
	"fmt"
	"net/http"
	"strings"
	"testing"
	"time"

	// 3rd Party
	"github.com/satori/go.uuid"

	// Merlin
	"kubesploit/pkg/core"
	"kubesploit/pkg/messages"
	"kubesploit/test/testServer"
)

// TestNewHTTPAgent ensure the agent.New function returns a http agent without error
func TestNewHTTPAgent(t *testing.T) {
	_, err := New("http", "https://127.0.0.1:8080", "", "test", "http://127.0.0.1:8081", "", false, false)

	if err != nil {
		t.Error(err)
	}
}

// TestNewHTTPSAgent ensure the agent.New function returns a https agent without error
func TestNewHTTPSAgent(t *testing.T) {
	_, err := New("https", "https://127.0.0.1:8080", "", "test", "http://127.0.0.1:8081", "", false, false)

	if err != nil {
		t.Error(err)
	}
}

// TestNewH2CAgent ensure the agent.New function returns a HTTP/2 clear-text agent without error
func TestNewH2CAgent(t *testing.T) {
	_, err := New("h2c", "https://127.0.0.1:8080", "", "test", "http://127.0.0.1:8081", "", false, false)

	if err != nil {
		t.Error(err)
	}
}

// TestNewH2Agent ensure the agent.New function returns a HTTP/2 agent without error
func TestNewH2Agent(t *testing.T) {
	_, err := New("h2", "https://127.0.0.1:8080", "", "test", "http://127.0.0.1:8081", "", false, false)

	if err != nil {
		t.Error(err)
	}
}

// TestNewHQAgent ensure the agent.New function returns a HTTP/3 agent without error
func TestNewHQAgent(t *testing.T) {
	_, err := New("http3", "https://127.0.0.1:8080", "", "test", "http://127.0.0.1:8081", "", false, false)

	if err != nil {
		t.Error(err)
	}
}

// TestKillDate sends a message with a kill date that has been exceeded
func TestKillDate(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8080", "", "test", "", "", false, false)

	if err != nil {
		t.Error(err)
	}

	agent.KillDate = 1560616599

	errRun := agent.Run()
	// TODO the function won't actually return unless there is an error
	if errRun == nil {
		t.Errorf("the agent did not quit when the killdate was exceeded")
	}
}

// TestFailedCheckin test for the agent to exit after the amount of failed checkins exceeds the agent's MaxRetry setting
func TestFailedCheckin(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8080", "", "test", "", "", false, false)

	if err != nil {
		t.Error(err)
	}

	agent.FailedCheckin = agent.MaxRetry

	errRun := agent.Run()
	if errRun == nil {
		t.Errorf("the agent did not quit when the maximum number of failed checkin atttempts were reached")
	}
}

// TestInvalidMessageType sends a valid message.Base with an invalid Type string
func TestInvalidMessageType(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8080", "", "test", "", "", false, false)

	if err != nil {
		t.Error(err)
	}

	m := messages.Base{
		Version: 1.0,
		ID:      agent.ID,
		Type:    "NotReal",
		Token:   agent.JWT,
	}
	_, errSend := agent.sendMessage("POST", m)
	if errSend == nil {
		t.Error("agent handler processed an invalid message type without returning an error")
	}
}

// TestInvalidMessage sends a structure that is not a valid message.Base
func TestInvalidMessage(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8081", "", "test", "", "", false, false)

	if err != nil {
		t.Error(err)
	}

	//signalling chans for start/end of test
	setup := make(chan struct{})
	ended := make(chan struct{})

	go testserver.TestServer{}.Start("8081", ended, setup, t)
	//wait until set up
	<-setup

	type testMessage struct {
		Alpha   string
		Number  int64
		Boolean bool
	}

	m := testMessage{
		Alpha:   "TestString",
		Number:  1337,
		Boolean: false,
	}

	// Can't use agent.sendMessage because it only accepts valid message.Base objects

	// Convert messages.Base to gob
	messageBytes := new(bytes.Buffer)
	errGobEncode := gob.NewEncoder(messageBytes).Encode(m)
	if errGobEncode != nil {
		t.Errorf("there was an error gob encoding the message:\r\n%s", errGobEncode.Error())
		return
	}

	// Get JWE
	jweString, errJWE := core.GetJWESymetric(messageBytes.Bytes(), agent.secret)
	if errJWE != nil {
		t.Errorf("there was an error getting the JWE:\r\n%s", errJWE.Error())
		return
	}

	// Encode JWE into gob
	jweBytes := new(bytes.Buffer)
	errJWEBuffer := gob.NewEncoder(jweBytes).Encode(jweString)
	if errJWEBuffer != nil {
		t.Errorf("there was an error gob encoding the JWE:\r\n%s", errJWEBuffer.Error())
		return
	}

	req, reqErr := http.NewRequest("POST", agent.URL, jweBytes)
	if reqErr != nil {
		t.Errorf("there was an error sending the POST request:\r\n%s", reqErr.Error())
		return
	}

	if req != nil {
		req.Header.Set("User-Agent", agent.UserAgent)
		req.Header.Set("Content-Type", "application/octet-stream; charset=utf-8")
		req.Header.Set("Authorization", fmt.Sprintf("Bearer %s", agent.JWT))
	}

	// Send the request
	var client = *agent.Client
	resp, err := client.Do(req)
	if err != nil {
		t.Errorf("there was an error with the HTTP client while performing a POST:\r\n%s", err.Error())
		return
	}

	close(ended)

	if resp == nil {
		t.Error("the server did not return a response")
		return
	}

	if resp.StatusCode != 404 {
		t.Error("the merlin server did not return a 404 for an invalid message type")
	}

}

// TestPSK ensure that the agent can't successfully communicate with the server using the wrong PSK
func TestPSK(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8080/merlin", "", "test", "", "", false, false)

	if err != nil {
		t.Error(err)
	}
	agent.WaitTime = 5000 * time.Millisecond
	k := sha256.Sum256([]byte("wrongPassword"))
	agent.secret = k[:]

	//signalling chans for start/end of test
	setup := make(chan struct{})
	ended := make(chan struct{})

	go testserver.TestServer{}.Start("8080", ended, setup, t)
	//wait until set up
	<-setup

	m := messages.Base{
		Version: 1.0,
		ID:      agent.ID,
		Type:    "StatusOk",
		Token:   agent.JWT,
	}

	_, errSend := agent.sendMessage("POST", m)
	if errSend == nil {
		t.Error("Agent successfully sent an encrypted message using the wrong key")
		return
	}

	close(ended)
}

// TestWrongUUID sends a valid message to an agent using a UUID that is different from the running agent
func TestWrongUUID(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8080", "", "test", "", "", false, false)

	if err != nil {
		t.Error(err)
	}

	m := messages.Base{
		Version: 1.0,
		ID:      uuid.NewV4(),
		Type:    "ServerOk",
		Token:   agent.JWT,
	}

	// Send a message with a new UUID that does not match the agent; Expecting agent to return an error
	_, errHandler := agent.messageHandler(m)
	if errHandler == nil {
		t.Error("the agent handled a message with a wrong UUID without returning an error")
	}

	if errHandler != nil {
		if !strings.Contains(errHandler.Error(), "the input message UUID did not match this agent's UUID") {
			t.Error(errHandler)
		}
	}
}

// TestInvalidHTTPTrafficPayload sends a gob encoded string to the server to ensure it handles invalid traffic
func TestInvalidHTTPTrafficPayload(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8080", "", "test", "", "", false, false)

	if err != nil {
		t.Error(err)
	}

	m := messages.Base{
		Version: 1.0,
		ID:      agent.ID,
		Type:    "BadPayload",
		Token:   agent.JWT,
	}

	_, errHandler := agent.sendMessage("POST", m)
	if errHandler == nil {
		t.Error("the agent handled a message with a wrong UUID without returning an error")
	}
}

// TestAuthentication verifies successful authentication using the correct PSK
func TestAuthentication(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8082/merlin", "", "test", "", "", false, false)

	if err != nil {
		t.Error(err)
		return
	}
	agent.WaitTime = 5000 * time.Millisecond

	//signalling chans for start/end of test
	setup := make(chan struct{})
	ended := make(chan struct{})

	go testserver.TestServer{}.Start("8082", ended, setup, t)
	//wait until set up
	<-setup

	authenticated := agent.initialCheckIn()
	if authenticated == false {
		t.Error("the agent did not successfully authenticate")
	}
	close(ended)
}

// TestBadAuthentication verifies unsuccessful authentication using the wrong PSK
func TestBadAuthentication(t *testing.T) {
	agent, err := New("h2", "https://127.0.0.1:8083", "", "neverGonnaGiveYouUp", "", "", false, false)

	if err != nil {
		t.Error(err)
		return
	}
	agent.WaitTime = 5000 * time.Millisecond

	//signalling chans for start/end of test
	setup := make(chan struct{})
	ended := make(chan struct{})

	go testserver.TestServer{}.Start("8083", ended, setup, t)
	//wait until set up
	<-setup

	authenticated := agent.initialCheckIn()
	if authenticated != false {
		t.Error("the agent successfully authenticated with the wrong PSK")
	}
	close(ended)
}

// Bad content-type header
// TODO test every function of the message handler
