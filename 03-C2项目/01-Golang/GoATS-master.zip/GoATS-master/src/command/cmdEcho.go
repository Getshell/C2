package command

import "fmt"

func Echo(msg string) {
	fmt.Println(msg)
}