package rat

type Region interface {
	Start() int
	End() int
}
