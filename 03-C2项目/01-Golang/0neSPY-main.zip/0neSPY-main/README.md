# :bomb: 0neSPY - Under Construction 


## :bug: Anti-Debugging Techniques 

<a href="https://anti-debug.checkpoint.com/">more info</a>

## :link: Persistent Connection
<ul>
  <li>TG C2 Backup</li>
  <li>Registry AutoStart</li>
</ul>

## :mag: Evasions Techniques
<ul>
  <li>Self-Destroy</li>
  <li>Memory Inject</li>
  <li>Black List IP</li>
  <li>Black List HWID</li>
  <li>Black List Users</li>
  <li>Black List HostName</li>

 
</ul>
<a href="https://evasions.checkpoint.com/">more info</a>

## :books: Technology
<ul>
  <li>GoLang</li>
  <li>PHP - Apache</li>
  <li>MySQL - PhpMyAdmin
</ul>

## :wrench: Features
<ul>
  <li>Screen-Share</li>
  <li>Interactive-Shell</li>
  <li>File-Transfer-Protocol</li>
</ul>

# Install & Build


```bash
...
```
