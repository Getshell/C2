var command = "calc.exe";
var call_shell = "WScript.Shell";
var obj = new ActiveXObject(call_shell);
obj.Run(command); 