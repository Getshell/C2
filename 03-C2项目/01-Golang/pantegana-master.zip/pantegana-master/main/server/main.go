package main

import server "github.com/cassanof/pantegana/server"

func main() {
	server.RunServer()
}
