Console (Client)
=================

Contains the entrypoint for the console client
