WireGuard
==========

This package implements commands related to WireGuard functionality such as `wg-socks` and `wg-portfwd`

__NOTE:__ Listener code for WireGuard (and all other protocols) is located in the `client/command/jobs` package

