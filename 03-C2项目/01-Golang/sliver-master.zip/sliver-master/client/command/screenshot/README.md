Screenshot
===========

Screenshot command implementation.

