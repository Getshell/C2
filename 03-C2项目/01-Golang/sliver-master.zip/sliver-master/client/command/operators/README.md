Operators
==========

Operator related command implementations.

__NOTE:__ Some operator-related commands are server-side only and are located instead in `server/console`
