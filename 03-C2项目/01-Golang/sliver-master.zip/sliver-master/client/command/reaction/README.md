Reaction
=========

Commands to set a reaction, or unset a reaction. Reactions allow the operator to automate commands in response to event(s).

