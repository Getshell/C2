Style
======

Defines terminal interface styles.
