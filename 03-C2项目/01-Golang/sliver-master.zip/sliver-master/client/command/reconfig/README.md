Reconfig
=========

Commands used to reconfigure beacon/session times and metadata
