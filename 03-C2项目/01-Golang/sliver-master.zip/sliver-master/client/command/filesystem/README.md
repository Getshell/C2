Filesystem
==========

This package implements file system commands such as `ls`, `cd`, `rm`, `download`, `upload`, etc.