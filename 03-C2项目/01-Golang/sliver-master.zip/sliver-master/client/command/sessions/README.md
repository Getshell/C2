Sessions
=========

Session related command implementations.
