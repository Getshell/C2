Beacons
========

This package implements the beacons command, which can be used to list and interact with beacons.
