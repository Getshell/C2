Exec
====

Implements execution related commands like `execute`, `execute-shellcode`, `execute-assembly`, etc.
