#!/bin/bash
docker build . -t torat
