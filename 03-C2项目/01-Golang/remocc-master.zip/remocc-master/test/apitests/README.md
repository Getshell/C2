These tests require the docker-compose to have brought up the containers
