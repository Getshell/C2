Package controller provides the control aspects of Remocc
