package main


import (
    "github.com/rraks/remocc/pkg/controller"
)

func main() {
    controller.Start()
}
