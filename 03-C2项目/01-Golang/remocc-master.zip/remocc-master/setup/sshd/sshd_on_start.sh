#!/bin/bash

sleep 1
/usr/sbin/sshd -f /root/.ssh/sshd_config
