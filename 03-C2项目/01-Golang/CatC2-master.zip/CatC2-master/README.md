# CatC2
A simple C2 like Slovakia. Based on the Mirai(未来) cnc with ssh.
<h1> You can use this c2 for free but please just credit me. </h1>

<h3>⚡️ Todo: </h3>

- [x] Secure Shell CNC Base
- [ ] Command System
- [ ] API System
- [x] Gradient Generator
- [ ] Ban System
- [ ] Kick System
- [x] User System
- [x] Database
- [x] Attack System 

<h3>⚡️ Current Features: </h3>

- Secure shell based command and control.
- Argon2 hashed passwords

<h3>⚡️ Libraries: </h3>

- <a href="https://github.com/gliderlabs/ssh">GliderLabs SSH (GliderLabs)</a>
- <a href="https://github.com/spf13/viper">Viper (spf13)</a>
- <a href="https://github.com/matthewhartstonge/argon2.git"> Argon2 (matthewhartstonge)</a>
