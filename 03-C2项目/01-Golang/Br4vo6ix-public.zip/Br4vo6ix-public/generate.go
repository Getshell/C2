package chungus

//go:generate go run github.com/99designs/gqlgen
