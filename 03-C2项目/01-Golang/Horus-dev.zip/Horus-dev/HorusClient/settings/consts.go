package settings

const EmptyString = ""
