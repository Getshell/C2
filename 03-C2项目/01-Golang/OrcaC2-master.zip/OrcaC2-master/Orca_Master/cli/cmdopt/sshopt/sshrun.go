package sshopt

type SshRunStruct struct {
	SshStruct SshOption
	Command   string
}
