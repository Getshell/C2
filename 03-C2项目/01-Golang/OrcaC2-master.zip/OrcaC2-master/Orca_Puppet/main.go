package main

import (
	"Orca_Puppet/define/setting"
)

func main() {
	setting.SetUp()
}
