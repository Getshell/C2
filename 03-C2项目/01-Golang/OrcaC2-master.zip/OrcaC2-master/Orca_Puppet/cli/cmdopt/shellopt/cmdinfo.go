package shellopt

// CmdInfo 消息结构
type CmdInfo struct {
	Context string //信息内容
	Attach  string //附加信息
}
