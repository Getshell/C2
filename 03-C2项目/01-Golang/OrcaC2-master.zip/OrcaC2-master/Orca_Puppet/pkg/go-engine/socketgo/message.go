package socketgo

type LuMessage struct {
	Id   int
	Flag int
	Data []byte
}
