package main

import "GC2-sheet/cmd"

func main(){

	cmd.Execute()

}