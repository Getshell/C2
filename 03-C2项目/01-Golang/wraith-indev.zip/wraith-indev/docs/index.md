# Wraith Documentation

---

The documentation is currently work-in-progress and subject to significant changes as the project develops!

---

- [Quickstart Guide](quickstart.md)
- [Project Architecture](architecture.md)
- [Build Instructions](building.md)
- [Configuration](configuration.md)
- [Writing a Module](modules.md)
