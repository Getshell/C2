package stdmod
