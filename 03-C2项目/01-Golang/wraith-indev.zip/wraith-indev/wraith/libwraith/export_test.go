package libwraith

//
// This file exports some internal code for/when testing only
//

type Shm struct {
	shm
}
