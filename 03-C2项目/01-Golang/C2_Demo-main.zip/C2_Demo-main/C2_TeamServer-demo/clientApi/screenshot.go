package clientApi

import (
	"github.com/gin-gonic/gin"
)

func Screenshot(c *gin.Context)  {

}
