package clientApi

import "github.com/gin-gonic/gin"

func RunCmd(c *gin.Context){

}