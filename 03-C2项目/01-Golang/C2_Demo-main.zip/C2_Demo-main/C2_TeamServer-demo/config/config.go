package config
//服务端全局常量配置。config.json给用户配置

const (
	Hosts_Api = "/v1"
	Server_Version = "0.0.1"
)

const (
	HostServer_Ip = "0.0.0.0"
	HostServer_Port="88"
)

const (
	TeamServer_Ip = "0.0.0.0"
	TeamServer_Port="89"
)

const Jwt_key = "demo"