---
name: Others
about: Any other issues
title: ''
labels: ''
assignees: ''

---

<!-- Check the checkbox, and delete this line, write as you pleased. -->

- [ ] | I do searched all the issues in the current repo, and confirm that there's no duplicate.

## Software Details

**Software Version (please complete the following information):**
 - OS: [e.g. Debian 8]
 - Arch: [e.g. amd64]
 - Version: [e.g. v1.0.0]
 
## Other Details


