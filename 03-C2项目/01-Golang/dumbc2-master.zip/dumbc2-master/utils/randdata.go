package utils

import (
	"bufio"
	"math/rand"
	"os"
	"strings"
	"time"
	"unsafe"
)

func RandMathInt64(a int) int64 {
	return int64(rand.Intn(a))
}

func RandString(n int) string {
	var src = rand.NewSource(time.Now().UnixNano())
	const letterBytes = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	const (
		letterIdxBits = 6                    // 6 bits to represent a letter index
		letterIdxMask = 1<<letterIdxBits - 1 // All 1-bits, as many as letterIdxBits
		letterIdxMax  = 63 / letterIdxBits   // # of letter indices fitting in 63 bits
	)
	b := make([]byte, n)
	// A src.Int63() generates 63 random bits, enough for letterIdxMax characters!
	for i, cache, remain := n-1, src.Int63(), letterIdxMax; i >= 0; {
		if remain == 0 {
			cache, remain = src.Int63(), letterIdxMax
		}
		if idx := int(cache & letterIdxMask); idx < len(letterBytes) {
			b[i] = letterBytes[idx]
			i--
		}
		cache >>= letterIdxBits
		remain--
	}
	return *(*string)(unsafe.Pointer(&b))
}

func ReadUserInput() string {
	reader := bufio.NewReader(os.Stdin)
	var data string
	data, _ = reader.ReadString('\n')
	data = strings.TrimSuffix(data, "\n")
	data = strings.TrimSuffix(data, "\r")
	return data
}
