# Pull Request

## Description
(REPLACE ME WITH A DESCRIPTION OF WHAT THIS PR CONTRIBUTES. INCLUDE REFERENCES TO ISSUES OR TODO ITEMS/BUGS BEING ADDRESSED IN THIS DESCRIPTION)

## Features
(REPLACE ME WITH A LIST OF FEATURES/FUNCTIONALITY/BUG FIXES)
- Adds example features
- Fixes example bug


## Screenshot(s)/Change Detail(s) (Optional)
(REPLACE ME WITH SCREENSHOT OR ASCIICINEMA OF THE FEATURE)
**NOTE:** This is _required_ unless the change is a configuration or code specific change that is not visually reflected. In these cases please provide a snippet of the change/expected output.


**NOTICE:** All PRs that deviate from this format with be closed regardless of their validity. Please stick to the format if you want your PR reviewed.