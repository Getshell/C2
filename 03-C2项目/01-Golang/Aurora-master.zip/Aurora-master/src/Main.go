package main

import (
	. "Aurora/src/internal"
)

func main() {
	a := NewAurora()
	a.Start()
}
