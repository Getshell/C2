# Aurora RAT

## About

Aurora RAT or Remote Administration Tool is written in Go.

This project was started to learn networking in go and get myself started in the security field.

## Usage

Compile and run Main.go then run the stub on whatever computer you wish to control.

## Stub

The stub can be found [here](https://github.com/alanbaumgartner/Aurora-Stub).