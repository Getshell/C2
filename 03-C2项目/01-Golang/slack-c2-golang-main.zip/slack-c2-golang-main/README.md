# slack-c2-golang
隐藏c2的巧妙方法使用slack平台   

可以在我的频道中看到详细使用哦   
https://www.bilibili.com/video/BV1pR4y1K7Fs/

