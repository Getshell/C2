package helper

// Service ...
type Service struct{}
