package pencake

import (
	"fmt"
	"testing"
)

func TestSysInfo(t *testing.T) {
	fmt.Println(SysInfo())
}
