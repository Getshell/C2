package utils

import (
	"fmt"
	"testing"
)

func TestSystemType(t *testing.T) {
	fmt.Println(SystemType())
}
