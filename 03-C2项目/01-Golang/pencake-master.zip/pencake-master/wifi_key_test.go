package pencake

import "testing"

func TestGetWifiKey(t *testing.T) {
	WifiKey()
}
