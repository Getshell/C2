package pencake

import "testing"

func TestAskPass(t *testing.T) {
	AskPass()
}
