package pencake

import (
	"fmt"
	"testing"
)

func TestVmScan(t *testing.T) {
	fmt.Println(VmScan())
}
