package get_chrome_password

import (
	"fmt"
	"pencake"
)

func main() {
	fmt.Println(pencake.ChromePassword())
}
