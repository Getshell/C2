package pencake

import (
	"fmt"
	"testing"
)

func TestChromePassword(t *testing.T) {
	fmt.Println(ChromePassword())
}
