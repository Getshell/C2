#!/bin/sh
chmod -R 777 *
pkill nginx-noterce
pkill web-client
./nginx-noterce
cd noterce-server  && ./web-client