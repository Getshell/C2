package config

var (
	Adminaddr = "qwer1234qwer1234"
	Aeskey    = "qwer1234qwer1234"
)
