package conf

const (
	TransThreads int = 4
	Seedid           = "fa801f84020cadc6914ef9b11482b4ccaf09e5cc282e77881c38bdded436cc75"
	Hunterid         = "monitor"
	AesKey           = "whatswrongwithUu"
	IvKey            = "whatswrongwithUu"
	RsaPublicKey     = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAximut2j7W5ISBb//heyf
umaN5pscUWhgJSAw/dHrlKqFhwU0pB1wRmMrW7UCEJG0KLMBrXqvak5GWAv4nU/e
v9kJohatyFvZYfEEWrlcqHCmJFW5QcGNnRG52TG8bU6Xk7ide1PTmPmrUlXAEwys
g4iYeWxCOpO9c4P7CLw/XyoHZ/yPXf/xPJNxxMpaudux1WAZBg+a1j1bilS5MBi6
0QMmE62OvKl2QpfTqFTDllh+UTouNzwt4fnEH5cQnhXxdDH7RGtj1Rnm7w1jwWr4
mqGPzuE5KeNlPNPtN770fbSv0qORG7HZ4sJFv59Rs9fY7j64dJfNY5sf1Z31reoJ
IwIDAQAB
-----END PUBLIC KEY-----`
)
