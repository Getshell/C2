# JBStrike

Currently isn't functional, still W.I.P.
Implant is currently Windows only but the client/server is cross-platform.

## Features

- Upload
- Download
- Shell-exec 

## Requirements
 
- Vistual Studio (C++ Implant)
- Go ( client & teamserver )

## Future...

- Execute-Assembly
- LDAP Domain Queryer
- DLL Based Plugin System