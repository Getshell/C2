package main

import "github.com/0xjbb/jbstrike/client/cmd"
import "github.com/desertbit/grumble"

func main() {
	grumble.Main(cmd.App)
}
