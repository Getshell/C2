#pragma once
//Defenitions for windows api calls.



void getFnPtr(std::string lib, std::string func) {
	


}