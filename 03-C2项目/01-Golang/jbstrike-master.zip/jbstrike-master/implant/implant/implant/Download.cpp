#include "Download.h"


void jbstrike::Downloader::Execute(std::vector<std::string> args) const {
	//this->http->Get("","");


}