#pragma once
#include <string>


struct Config {
	int SleepTime; // Time the implant sleeps.
	std::string UriString; // Server URI string http://<ip>:<port>
};