package data

type ZeekUIDRecord struct {
	Conn struct {
		OrigBytes int64
		RespBytes int64
		Duration  float64
	}
}
