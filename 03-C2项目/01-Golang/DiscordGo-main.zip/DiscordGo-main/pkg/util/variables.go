// Package constants contains sensitive informations like the serverID and BotToken
package util

var ServerID = "XXXXXXXXXXXXXXXXX"
var BotToken = "XXXXXXXXXXXXXXXXX"
