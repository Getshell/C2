# DNS C2 Server

This is a rough try of a c2 dns server setup, including an agent as well.

![poc](/assets/images/demo.gif)
