package config

// this package includes global variables

// SSHport is the port on which ssh listener will listen
var SSHport int

// Handlerport is the port on which https listener will listen
var Handlerport int
