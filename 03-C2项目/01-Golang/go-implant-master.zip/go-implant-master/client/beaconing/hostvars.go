package beaconing

// these get generated at runtime - no need for obfuscation
var UID string
var OSINFO string
var USERNAME string
var HOSTNAME string
