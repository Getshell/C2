// +build DEBUG

package config

const DEBUG = true
