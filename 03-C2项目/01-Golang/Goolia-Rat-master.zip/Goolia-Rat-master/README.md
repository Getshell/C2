# Goolia
I'm trying to innovate the idea of RAT. This is an example of how gRPC can be used in any way!

A detailed description will be made as soon as possible.

Feel free to collaborate!
