# Nemesis C2

This is a custom C2 project that I am working on. The Team Server is created using Golang. The Client side GUI is also created using Golang (with the `fyne` framework)

## TODO

- Create Agents in C/C++
- Create mechanism for communication between agents and the C2
- Create GUI for interactive with the agents
