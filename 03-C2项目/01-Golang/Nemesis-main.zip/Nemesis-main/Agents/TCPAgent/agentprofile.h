char *ip = "192.168.181.136";
int port = 1331;
char *agentID = "abcd\r\n\r\n";

