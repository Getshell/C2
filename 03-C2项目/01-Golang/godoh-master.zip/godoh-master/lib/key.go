package lib

// AES key used to encrypt data blobs in communications
// $ openssl rand -hex 16
const cryptKey = `2589213f0c51583dcbaacbe0005e5908`
