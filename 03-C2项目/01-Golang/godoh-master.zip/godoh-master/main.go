package main

import "github.com/sensepost/godoh/cmd"

func main() {
	cmd.Execute()
}
