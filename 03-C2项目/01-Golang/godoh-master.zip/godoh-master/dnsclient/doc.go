// Package dnsclient contains logic to interact with different DoH providers
// ref: https://github.com/curl/curl/wiki/DNS-over-HTTPS
package dnsclient
