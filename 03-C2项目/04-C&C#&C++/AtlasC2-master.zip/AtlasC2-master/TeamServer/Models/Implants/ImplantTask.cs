﻿namespace TeamServer.Models
{
    public class ImplantTask
    {
        public string Id { get; set; }
        public string Command { get; set; }
        public string Args { get; set; }
        public string File { get; set; }
    }
}
