﻿using System;

namespace APIModels
{
    public class Class1
    {
    }
}
