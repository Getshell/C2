# GithubC2
Github as C2 Demonstration , free API = free C2 Infrastructure

## Demo
https://user-images.githubusercontent.com/110354855/192076474-3c1884f8-4a59-4944-b0d6-9dc59c7692f0.mp4
