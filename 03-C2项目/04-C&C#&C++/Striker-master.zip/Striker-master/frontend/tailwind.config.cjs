/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html", "./src/**/*.{html,svelte}"],
  theme: {
    extend: {},
  },
  plugins: [],
}
