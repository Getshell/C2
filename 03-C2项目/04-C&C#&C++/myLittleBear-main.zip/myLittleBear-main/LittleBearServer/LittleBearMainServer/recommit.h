#pragma once

#include <windows.h>


class Recommit {
public:
	static int __stdcall recommit();
};