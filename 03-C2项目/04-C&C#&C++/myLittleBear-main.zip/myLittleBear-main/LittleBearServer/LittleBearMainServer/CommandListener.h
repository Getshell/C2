
#include <windows.h>

class CommandListener {
public:
	static int __stdcall NetWorkCommandListener();
};
