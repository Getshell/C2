
#include <windows.h>

class DataListener {
public:
	static int __stdcall NetWorkDataListener();

};

