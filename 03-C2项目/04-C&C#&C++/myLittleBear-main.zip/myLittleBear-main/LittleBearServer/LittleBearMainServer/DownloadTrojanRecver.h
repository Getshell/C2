
#include <windows.h>
#include "main.h"



DWORD __stdcall DownloadTrojan(LPNETWORKPROCPARAM lpparam);