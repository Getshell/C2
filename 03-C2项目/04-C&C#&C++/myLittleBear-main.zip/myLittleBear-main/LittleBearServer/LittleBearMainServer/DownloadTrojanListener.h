
#include <windows.h>

DWORD __stdcall DownloadTrojanListener();