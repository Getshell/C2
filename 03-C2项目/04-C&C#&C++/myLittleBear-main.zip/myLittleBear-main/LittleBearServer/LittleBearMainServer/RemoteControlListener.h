
#include <windows.h>

class RemoteControlServer {
public:
	static int __stdcall RemoteControlListener();
};

