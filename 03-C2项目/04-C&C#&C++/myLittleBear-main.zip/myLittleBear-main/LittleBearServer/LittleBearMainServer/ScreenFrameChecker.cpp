
#include <windows.h>

int ScreenFrameChecker(char * lpsrc,char * lpdst){
	return TRUE;
}