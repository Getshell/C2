#pragma once

#include <windows.h>

void mytest();