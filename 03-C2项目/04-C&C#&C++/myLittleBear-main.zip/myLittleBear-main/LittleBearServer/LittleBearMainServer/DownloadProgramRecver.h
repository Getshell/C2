
#include <windows.h>
#include <winsock.h>
#include "main.h"
#include "Public.h"




int __stdcall DownloadProgramRecver(LPNETWORKPROCPARAM pClientInfo);
