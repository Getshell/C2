
class RemoteControlServer {
public:
	static int __stdcall RemoteControlListener();
};

