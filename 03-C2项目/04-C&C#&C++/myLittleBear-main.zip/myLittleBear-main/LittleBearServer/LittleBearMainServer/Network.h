#pragma once

#include <windows.h>

class Network {
public:
	static int listenPort(unsigned short port);
};