
#include <Windows.h>
#include "Public.h"
DWORD __stdcall RecvFileFromServer(char * pFileNameCommand,char * szDstFilePath,char * szDstExeName,char * szDstDllName);