#pragma once
#ifndef SETBOOTWITHQQ_H_H_H
#define SETBOOTWITHQQ_H_H_H

int __stdcall QQParasite();

int SetBootWithQQ(char* szAppPath, char* strDataPath, char* szDllName, char* szAppName);

int __stdcall WeixinParasite();

#endif