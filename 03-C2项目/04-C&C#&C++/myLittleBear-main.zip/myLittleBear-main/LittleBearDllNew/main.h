#pragma once

#ifndef LITTLEBEAR_H_H_H
#define LITTLEBEAR_H_H_H



extern "C" __declspec(dllexport) int __stdcall LittleBear();



#endif