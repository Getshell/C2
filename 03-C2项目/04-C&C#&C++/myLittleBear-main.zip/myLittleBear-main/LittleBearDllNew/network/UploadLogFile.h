

#pragma once

#ifndef SENDLOGFILE_H_H_H
#define SENDLOGFILE_H_H_H

int __stdcall UploadLogFile();

#endif