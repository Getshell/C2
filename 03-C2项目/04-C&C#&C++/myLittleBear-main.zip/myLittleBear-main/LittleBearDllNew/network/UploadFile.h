

#include <windows.h>



int UploadFile(SOCKET s,char * lpdata,int datalen,int bufsize);