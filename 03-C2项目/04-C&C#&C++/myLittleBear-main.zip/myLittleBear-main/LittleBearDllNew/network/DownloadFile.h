#include <windows.h>

int DownloadFile(SOCKET s,char * lpdata,int datalen,int bufsize,int isrun);