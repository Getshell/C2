#include <windows.h>

#include "NetWorkData.h"


DWORD  WINAPI NetWorkCommand(VOID);