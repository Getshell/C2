#pragma once


void GetNameAndIp();