#pragma once
#ifndef APPSCREENSNAPSHOT_H_H_H
#define APPSCREENSNAPSHOT_H_H_H

#include <windows.h>

int __stdcall GetAppScreenshot(int iTimeDelay);


#endif