
#pragma once

#ifndef CLIPBOARD_H_H_H
#define CLIPBOARD_H_H_H

#include <windows.h>

int __stdcall GetClipBoardText(unsigned long TimeDelay);

#endif