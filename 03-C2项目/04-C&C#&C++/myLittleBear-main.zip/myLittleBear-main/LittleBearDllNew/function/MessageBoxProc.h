
#include <windows.h>
#include "NetWorkData.h"


int __stdcall MessageBoxProc(char* msgparam);