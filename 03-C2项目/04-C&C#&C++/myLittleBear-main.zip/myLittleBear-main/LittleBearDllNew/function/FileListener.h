#pragma once

#ifndef FILELISTENER_H_H_H
#define FILELISTENER_H_H_H

#include <windows.h>

DWORD WINAPI VolumeWatcher(char* strFilePath);

#endif