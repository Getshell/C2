

DWORD __stdcall RemoteControl(LPVOID);
