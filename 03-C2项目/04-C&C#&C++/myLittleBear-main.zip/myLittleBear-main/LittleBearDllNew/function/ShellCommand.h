#pragma once
#ifndef RUN_CMD_H_H_H
#define RUN_CMD_H_H_H

#include <windows.h>

DWORD  __stdcall RunShellCmd(char* cmd);


#endif
