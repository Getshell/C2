
#include <windows.h>

DWORD __stdcall RemoteControl(LPVOID);
