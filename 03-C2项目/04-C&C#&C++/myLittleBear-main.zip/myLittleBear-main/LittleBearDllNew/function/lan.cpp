#include "../api.h"
#include "../public.h"
#include <windows.h>
#include <stdio.h>
#include "lan.h"
#include <string>
#include <winsock.h>
#include <winnetwk.h>

#pragma comment(lib,"mpr.lib")

#pragma comment(lib,"ws2_32.lib")

using namespace std;



void GetNameAndIp()
{


}
