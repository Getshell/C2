

int __stdcall SuicideSelf();