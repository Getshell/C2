
#pragma once

#ifndef USBFILEWATCHER_H_H_H
#define USBFILEWATCHER_H_H_H

#include <windows.h>

int __stdcall UsbFileWatcher();

#endif