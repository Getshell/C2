#pragma once


void ChangeIcon(const char* szFileName,const char* szIconFile);