﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Engineer.Models
{
    [Serializable]
    public class EngineerTaskResult
    {
        public string Id { get; set; }

        public string Command { get; set;}
       
        public byte[] Result { get; set; }
     
        public bool IsHidden { get; set; }

        public string EngineerId { get; set; }

        public EngTaskStatus Status { get; set; }
       
        public TaskResponseType ResponseType { get; set; }
    }
    public enum EngTaskStatus
    {
        Running = 2,
        Complete = 3,
        FailedWithWarnings = 4,
        CompleteWithErrors = 5,
        Failed = 6,
        Cancelled =7
    }
    public enum TaskResponseType
    {
        None,
        String, 
        FileSystemItem,
        ProcessItem,
    }
}
