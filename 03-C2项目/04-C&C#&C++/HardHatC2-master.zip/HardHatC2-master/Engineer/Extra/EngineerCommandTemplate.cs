﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Engineer.Extra;
using Engineer.Models;

//namespace Engineer.Commands
//{
//    internal class EngineerCommandTemplate : EngineerCommand
//    {
//        public override string Name => throw new NotImplementedException();

//        public override string Execute(EngineerTask task)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
