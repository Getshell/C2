﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Engineer.Extra;


namespace Engineer.Functions
{
    public class SleepEnum
    {
        public enum SleepTypes
        {
            None, 
            Custom_RC4,
           // Ekko,
        }
        
    }
}
