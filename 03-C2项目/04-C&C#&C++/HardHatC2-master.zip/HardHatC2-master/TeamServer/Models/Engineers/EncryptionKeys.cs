﻿namespace TeamServer.Models.Engineers
{
    public class EncryptionKeys
    {
    }
}
