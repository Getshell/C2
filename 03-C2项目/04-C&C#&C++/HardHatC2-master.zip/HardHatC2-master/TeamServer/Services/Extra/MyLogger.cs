﻿using Newtonsoft.Json.Linq;
using Serilog;
using Serilog.Events;
using System;

namespace TeamServer.Services.Extra
{
    public class MyLogger : ILogger
    {
        public void Write(LogEvent logEvent)
        {
            throw new System.NotImplementedException();
        }

        

       
    }
}
