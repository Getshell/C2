package me.client.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class AESUtils {
    public static byte[] decrypt(String str) {
        byte[] context = null;
        try {
            String KeyString = LoadDLL.instance.GetKey().toString();
            byte[] bytes = KeyString.getBytes(StandardCharsets.UTF_8);
            SecretKeySpec spec = new SecretKeySpec(bytes,"AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE,spec);
            byte[] base64Context = Base64.getDecoder().decode(str);
            context = cipher.doFinal(base64Context);
        }catch (Exception e) {
            e.printStackTrace();
        }
        return context;
    }
    public static byte[] encryption(String str) throws Exception{
        String KeyString = LoadDLL.instance.GetKey().toString();
        byte[] key = KeyString.getBytes(StandardCharsets.UTF_8);
        SecretKeySpec spec = new SecretKeySpec(key,"AES");
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, spec);
        byte[] context = cipher.doFinal(str.getBytes(StandardCharsets.UTF_8));
        return Base64.getEncoder().encode(context);
    }
}
