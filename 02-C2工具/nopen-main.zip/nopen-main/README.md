# nopen (morerats)

<img width="1279" alt="23c60b3f4ca8bf0ad73a91e0e6d174c" src="https://user-images.githubusercontent.com/27001865/158942670-0df1d154-ca34-4b3d-961f-caa0ab62e000.png">

## “NOPEN”远控木马分析

近日，国家计算机病毒应急处理中心对名为“NOPEN”的木马工具进行了攻击场景复现和技术分析。该木马工具针对Unix/Linux平台，可实现对目标的远程控制。根据“影子经纪人”泄露的NSA内部文件，该木马工具为美国国家安全局开发的网络武器。“NOPEN”木马工具是一款功能强大的综合型木马工具，也是美国国家安全局接入技术行动处（TAO）对外攻击窃密所使用的主战网络武器之一。



## 【转载】 “NOPEN”远控木马分析报告

https://mp.weixin.qq.com/s/tNOOPm1z1qHUaqaTO3jtBg

## “NOPEN”远控木马分析报告

http://www.cverc.org.cn/head/zhaiyao/news20220218-1.htm

## morerats 

在方程式工具包中，morerats似乎是版本系列.工具包中最新的版本是4
