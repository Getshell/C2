#!/bin/bash

nim c -o:./nimc2 -r src/server/server.nim